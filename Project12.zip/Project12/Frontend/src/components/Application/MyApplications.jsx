import React, { useContext, useEffect, useState } from "react";
import { Context } from "../../main";
import axios from "axios";
import toast from "react-hot-toast";
import ResumeModal from "./ResumeModal";

const MyApplication = () => {
  const { user } = useContext(Context);
  const [applications, setApplications] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [resumeImageUrl, setResumeImageUrl] = useState("");
  const [displayResume, setDisplayResume] = useState(false);

  useEffect(() => {
    try {
      axios
        .get("http://localhost:4000/api/v1/application/jobseeker/getall", {
          withCredentials: true,
        })
        .then((res) => {
          setApplications(res.data.applications);
        });
    } catch (error) {
      toast.error(error.response.data.message);
    }
  }, []);

  const openModal = (imageUrl) => {
    setResumeImageUrl(imageUrl);
    setDisplayResume(true);
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
    setDisplayResume(false); // Add this line to reset the displayResume state
  };

  return (
    <section className="my_applications page">
      <div className="container">
        <h1 style={{ color: "cadetblue" }}>My Applications</h1>
        {applications.length <= 0 ? (
          <h4>No Applications Found</h4>
        ) : (
          applications.map((element) => {
            return (
              <JobSeekerCard
                element={element}
                key={element._id}
                openModal={() => openModal(element.resume.url)}
              />
            );
          })
        )}
      </div>
      {modalOpen && (
        <ResumeModal
          imageUrl={resumeImageUrl}
          onClose={closeModal}
          displayResume={displayResume}
        />
      )}
    </section>
  );
};

const JobSeekerCard = ({ element, openModal, displayResume }) => {
  return (
    <div className="job_seeker_card">
      <div className="detail">
        <h5>
          <span>Job Title:</span> {element.jobId.title}
        </h5>
        <p>
          <span>Name:</span> {element.name}
        </p>
        <p>
          <span>Email:</span> {element.email}
        </p>
        <p>
          <span>Phone:</span> {element.phone}
        </p>
        <p>
          <span>Address:</span> {element.address}
        </p>
        <p>
          <span>field Of Expertise:</span> {element.fieldOfExpertise}
        </p>
        <p>
          <span>work Experience:</span> {element.workExperience} Year
        </p>
        <p>
          <span>CoverLetter:</span> {element.coverLetter}
        </p>
        <div className="resume">
        {displayResume ? (
          <img
            src={element.resume.url}
            alt="resume"
            onClick={openModal}
          />
        ) : (
          <button onClick={openModal}>Display Resume</button>
        )}
      </div>
      </div>
      
    </div>
  );
};

export default MyApplication;